import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../controllers/transaction_controller.dart';
import '../../../core/theme.dart';
import '../../../core/global_styles.dart';
import '../../../data/models/transaction_model.dart';
import '../../../data/models/product_model.dart';
import '../../../routes/app_pages.dart';

// ════════════════════════════════════════════════════════════════════════════
//  Transaction View
// ════════════════════════════════════════════════════════════════════════════
class TransactionView extends GetView<TransactionController> {
  const TransactionView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgColor,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('GIAO DỊCH KHO'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.accentColor),
            onPressed: controller.fetchHistory,
          ),
        ],
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(height: 1, color: AppTheme.borderColor),
        ),
      ),
      body: Column(
        children: [
          _ActionButtons(),
          _FilterTabs(),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value && controller.history.isEmpty) {
                return const Center(child: CircularProgressIndicator(color: AppTheme.primaryColor));
              }
              if (controller.history.isEmpty) {
                return const EmptyState(
                  message: 'Chưa có giao dịch nào\nTạo phiếu nhập / xuất để bắt đầu',
                  icon: Icons.receipt_long_outlined,
                );
              }
              return RefreshIndicator(
                color: AppTheme.primaryColor,
                backgroundColor: AppTheme.cardColor,
                onRefresh: controller.fetchHistory,
                child: ListView.separated(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.history.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (_, i) => FadeSlideItem(
                    index: i,
                    child: _TransactionCard(transaction: controller.history[i]),
                  ),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _ActionButtons extends GetView<TransactionController> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Expanded(
            child: _ActionBtn(
              label: 'NHẬP KHO',
              icon: Icons.south_west_rounded,
              color: AppTheme.successColor,
              gradient: AppTheme.successGradient,
              onTap: () {
                controller.formType.value = 'IN';
                controller.draftItems.clear();
                Get.toNamed(Routes.CREATE_TRANSACTION);
              },
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _ActionBtn(
              label: 'XUẤT KHO',
              icon: Icons.north_east_rounded,
              color: AppTheme.dangerColor,
              gradient: AppTheme.dangerGradient,
              onTap: () {
                controller.formType.value = 'OUT';
                controller.draftItems.clear();
                Get.toNamed(Routes.CREATE_TRANSACTION);
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatefulWidget {
  final String label;
  final IconData icon;
  final Color color;
  final Gradient gradient;
  final VoidCallback onTap;
  const _ActionBtn({required this.label, required this.icon, required this.color, required this.gradient, required this.onTap});

  @override
  State<_ActionBtn> createState() => _ActionBtnState();
}

class _ActionBtnState extends State<_ActionBtn> with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 100));
    _scale = Tween(begin: 1.0, end: 0.96).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _ctrl.forward(),
      onTapUp: (_) { _ctrl.reverse(); widget.onTap(); },
      onTapCancel: () => _ctrl.reverse(),
      child: AnimatedBuilder(
        animation: _scale,
        builder: (_, child) => Transform.scale(scale: _scale.value, child: child),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: AppTheme.cardColor,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: widget.color.withOpacity(0.2)),
            boxShadow: [
              BoxShadow(color: widget.color.withOpacity(0.1), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ShaderMask(
                shaderCallback: (b) => widget.gradient.createShader(b),
                child: Container(
                  width: 48, height: 48,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.06),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(widget.icon, color: Colors.white, size: 24),
                ),
              ),
              const SizedBox(height: 10),
              ShaderMask(
                shaderCallback: (b) => widget.gradient.createShader(b),
                child: Text(
                  widget.label,
                  style: const TextStyle(
                    fontFamily: 'Sora', fontWeight: FontWeight.w700,
                    fontSize: 12, letterSpacing: 1.5, color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _FilterTabs extends GetView<TransactionController> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      const types = [null, 'IN', 'OUT'];
      const labels = ['Tất cả', 'Nhập kho', 'Xuất kho'];
      final colors = [AppTheme.primaryColor, AppTheme.successColor, AppTheme.dangerColor];

      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        child: Row(
          children: List.generate(3, (i) {
            final sel = controller.filterType.value == types[i];
            return GestureDetector(
              onTap: () {
                controller.filterType.value = types[i];
                controller.fetchHistory();
              },
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                margin: const EdgeInsets.only(right: 8),
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: sel ? colors[i].withOpacity(0.12) : AppTheme.cardColor,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: sel ? colors[i] : AppTheme.borderColor),
                ),
                child: Text(
                  labels[i],
                  style: TextStyle(
                    color: sel ? colors[i] : Colors.white54,
                    fontWeight: sel ? FontWeight.w700 : FontWeight.w400,
                    fontSize: 13, fontFamily: 'Inter',
                  ),
                ),
              ),
            );
          }),
        ),
      );
    });
  }
}

class _TransactionCard extends StatelessWidget {
  final Transaction transaction;
  const _TransactionCard({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final t = transaction;
    Color typeColor = switch (t.type) {
      'IN' => AppTheme.successColor,
      'OUT' => AppTheme.dangerColor,
      'ADJUST' => AppTheme.warningColor,
      _ => Colors.white54,
    };
    IconData typeIcon = switch (t.type) {
      'IN' => Icons.south_west_rounded,
      'OUT' => Icons.north_east_rounded,
      'ADJUST' => Icons.tune_rounded,
      _ => Icons.swap_horiz,
    };
    String typeLabel = switch (t.type) {
      'IN' => 'Phiếu Nhập Kho',
      'OUT' => 'Phiếu Xuất Kho',
      'ADJUST' => 'Điều Chỉnh',
      _ => t.type,
    };

    return ZenithCard(
      borderColor: typeColor.withOpacity(0.1),
      child: Row(
        children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              color: typeColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(typeIcon, color: typeColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(typeLabel, style: AppTheme.titleStyle.copyWith(fontSize: 14)),
                const SizedBox(height: 3),
                Text(
                  'Bởi: ${t.userFullName ?? 'N/A'} · ${t.warehouseName ?? ''}',
                  style: AppTheme.captionStyle.copyWith(fontSize: 11),
                ),
                if (t.items.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    t.items.map((i) => i.productName ?? 'SP').take(2).join(', ') +
                        (t.items.length > 2 ? ' +${t.items.length - 2} khác' : ''),
                    style: AppTheme.captionStyle.copyWith(fontSize: 11, color: const Color(0xFF37474F)),
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              ZenithBadge(
                label: t.type == 'IN' ? '+${t.totalQuantity}' : '-${t.totalQuantity}',
                color: typeColor,
              ),
              const SizedBox(height: 6),
              Text(
                DateFormat('dd/MM HH:mm').format(t.createdAt.toLocal()),
                style: AppTheme.monoStyle.copyWith(fontSize: 10),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
//  Create Transaction View
// ════════════════════════════════════════════════════════════════════════════
class CreateTransactionView extends GetView<TransactionController> {
  const CreateTransactionView({super.key});

  @override
  Widget build(BuildContext context) {
    final notesCtrl = TextEditingController();
    final refCtrl = TextEditingController();
    final argType = Get.arguments as String?;
    if (argType != null) {
      controller.formType.value = argType;
      controller.draftItems.clear();
    }

    return Obx(() {
      final isIn = controller.formType.value == 'IN';
      final typeColor = isIn ? AppTheme.successColor : AppTheme.dangerColor;
      final typeGradient = isIn ? AppTheme.successGradient : AppTheme.dangerGradient;

      return Scaffold(
        backgroundColor: AppTheme.bgColor,
        appBar: AppBar(
          backgroundColor: AppTheme.surfaceColor,
          title: ShaderMask(
            shaderCallback: (b) => typeGradient.createShader(b),
            child: Text(
              isIn ? 'NHẬP KHO' : 'XUẤT KHO',
              style: const TextStyle(
                fontFamily: 'Sora', fontWeight: FontWeight.w800,
                fontSize: 15, letterSpacing: 2, color: Colors.white,
              ),
            ),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_new),
            onPressed: Get.back,
          ),
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(1),
            child: Container(height: 1, color: AppTheme.borderColor),
          ),
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _WarehouseSelector(typeColor: typeColor),
                    const SizedBox(height: 20),
                    _DraftItemsList(isIn: isIn),
                    const SizedBox(height: 12),
                    _AddProductButton(isIn: isIn, typeColor: typeColor),
                    const SizedBox(height: 20),
                    TextField(
                      controller: notesCtrl,
                      maxLines: 2,
                      style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
                      decoration: const InputDecoration(
                        labelText: 'Ghi chú (tuỳ chọn)',
                        prefixIcon: Icon(Icons.notes_rounded, size: 18),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: refCtrl,
                      style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
                      decoration: const InputDecoration(
                        labelText: 'Mã tham chiếu / Số phiếu',
                        prefixIcon: Icon(Icons.tag_rounded, size: 18),
                      ),
                    ),
                    const SizedBox(height: 28),
                  ],
                ),
              ),
            ),
            _SubmitBar(isIn: isIn, notesCtrl: notesCtrl, refCtrl: refCtrl),
          ],
        ),
      );
    });
  }
}

class _WarehouseSelector extends GetView<TransactionController> {
  final Color typeColor;
  const _WarehouseSelector({required this.typeColor});

  @override
  Widget build(BuildContext context) {
    return ZenithCard(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      borderColor: typeColor.withOpacity(0.15),
      child: Row(
        children: [
          Icon(Icons.warehouse_outlined, color: typeColor, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Obx(() => DropdownButton<Warehouse>(
              value: controller.selectedWarehouse.value,
              isExpanded: true,
              underline: const SizedBox.shrink(),
              dropdownColor: AppTheme.elevatedColor,
              style: const TextStyle(color: Colors.white, fontFamily: 'Inter', fontSize: 14),
              hint: const Text('Chọn kho', style: TextStyle(color: Color(0xFF546E7A))),
              items: controller.warehouses.map((w) =>
                DropdownMenuItem(value: w, child: Text(w.name)),
              ).toList(),
              onChanged: (w) => controller.selectedWarehouse.value = w,
            )),
          ),
        ],
      ),
    );
  }
}

class _DraftItemsList extends GetView<TransactionController> {
  final bool isIn;
  const _DraftItemsList({required this.isIn});

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (controller.draftItems.isEmpty) {
        return ZenithCard(
          padding: const EdgeInsets.all(28),
          child: Center(
            child: Column(
              children: [
                Container(
                  width: 52, height: 52,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.03),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(Icons.add_shopping_cart_outlined, size: 28, color: Color(0xFF37474F)),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Chưa có sản phẩm nào\nNhấn nút bên dưới để thêm',
                  style: TextStyle(color: Color(0xFF546E7A), fontSize: 13, fontFamily: 'Inter', height: 1.6),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      }

      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SectionHeader(
            title: '${controller.draftItems.length} sản phẩm',
            trailing: TextButton(
              onPressed: controller.draftItems.clear,
              child: const Text('Xóa tất cả', style: TextStyle(color: AppTheme.dangerColor, fontSize: 12, fontFamily: 'Inter')),
            ),
          ),
          const SizedBox(height: 10),
          ...controller.draftItems.asMap().entries.map((entry) {
            final i = entry.key;
            final item = entry.value;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: ZenithCard(
                borderColor: (isIn ? AppTheme.successColor : AppTheme.dangerColor).withOpacity(0.1),
                child: Row(
                  children: [
                    Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: (isIn ? AppTheme.successColor : AppTheme.dangerColor).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        isIn ? Icons.south_west_rounded : Icons.north_east_rounded,
                        color: isIn ? AppTheme.successColor : AppTheme.dangerColor,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.product.name, style: AppTheme.titleStyle.copyWith(fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis),
                          Text('Lô: ${item.batch.batchCode}', style: AppTheme.monoStyle.copyWith(fontSize: 10)),
                          if (!isIn)
                            Text('Còn: ${item.batch.currentQuantity}',
                                style: AppTheme.captionStyle.copyWith(fontSize: 10, color: AppTheme.warningColor)),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        _QtyBtn(
                          icon: Icons.remove_rounded,
                          color: AppTheme.dangerColor,
                          onTap: () {
                            if (item.quantity > 1) controller.updateDraftQty(i, item.quantity - 1);
                          },
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          child: Text(
                            '${item.quantity}',
                            style: AppTheme.numberStyle.copyWith(fontSize: 16),
                          ),
                        ),
                        _QtyBtn(
                          icon: Icons.add_rounded,
                          color: AppTheme.successColor,
                          onTap: () => controller.updateDraftQty(i, item.quantity + 1),
                        ),
                        const SizedBox(width: 4),
                        GestureDetector(
                          onTap: () => controller.draftItems.removeAt(i),
                          child: Container(
                            width: 28, height: 28,
                            decoration: BoxDecoration(
                              color: AppTheme.dangerColor.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.close_rounded, size: 14, color: AppTheme.dangerColor),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      );
    });
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 28, height: 28,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 16, color: color),
      ),
    );
  }
}

class _AddProductButton extends GetView<TransactionController> {
  final bool isIn;
  final Color typeColor;
  const _AddProductButton({required this.isIn, required this.typeColor});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: AppTheme.cardColor,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        builder: (_) => _AddProductSheet(controller: controller, isIn: isIn),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: typeColor.withOpacity(0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: typeColor.withOpacity(0.25), width: 1.5),
          boxShadow: [BoxShadow(color: typeColor.withOpacity(0.04), blurRadius: 12, offset: const Offset(0, 4))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(color: typeColor.withOpacity(0.15), shape: BoxShape.circle),
              child: Icon(Icons.add_rounded, color: typeColor, size: 18),
            ),
            const SizedBox(width: 10),
            Text(
              'THÊM SẢN PHẨM VÀO PHIẾU',
              style: TextStyle(
                color: typeColor, fontFamily: 'Sora',
                fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 1.2,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SubmitBar extends GetView<TransactionController> {
  final bool isIn;
  final TextEditingController notesCtrl;
  final TextEditingController refCtrl;
  const _SubmitBar({required this.isIn, required this.notesCtrl, required this.refCtrl});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 32),
      decoration: BoxDecoration(
        color: AppTheme.surfaceColor,
        border: const Border(top: BorderSide(color: AppTheme.borderColor)),
      ),
      child: Obx(() {
        final count = controller.draftItems.length;
        final total = controller.draftItems.fold<int>(0, (s, e) => s + e.quantity);
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (count > 0) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('$count sản phẩm', style: AppTheme.captionStyle),
                  Text(
                    'Tổng: $total',
                    style: AppTheme.titleStyle.copyWith(
                      color: isIn ? AppTheme.successColor : AppTheme.dangerColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
            ],
            ZenithButton(
              label: isIn ? 'HOÀN TẤT NHẬP KHO' : 'HOÀN TẤT XUẤT KHO',
              gradient: isIn ? AppTheme.successGradient : AppTheme.dangerGradient,
              icon: Icons.check_circle_outline,
              isLoading: controller.isSubmitting.value,
              onPressed: count == 0 ? null : () => controller.submitTransaction(
                notes: notesCtrl.text.trim(),
                ref: refCtrl.text.trim(),
              ),
            ),
          ],
        );
      }),
    );
  }
}

// ── Add Product Sheet ────────────────────────────────────────────────────────
class _AddProductSheet extends StatefulWidget {
  final TransactionController controller;
  final bool isIn;
  const _AddProductSheet({required this.controller, required this.isIn});

  @override
  State<_AddProductSheet> createState() => _AddProductSheetState();
}

class _AddProductSheetState extends State<_AddProductSheet> {
  Product? _selProduct;
  Batch? _selBatch;
  List<Product> _products = [];
  List<Batch> _batches = [];
  int _qty = 1;
  bool _loading = false;
  final _qtyCtrl = TextEditingController(text: '1');

  @override
  void initState() {
    super.initState();
    _loadProducts();
  }

  Future<void> _loadProducts() async {
    setState(() => _loading = true);
    try {
      final list = await widget.controller.loadProductsForType();
      setState(() { _products = list; _loading = false; });
    } catch (_) { setState(() => _loading = false); }
  }

  Future<void> _onProductSelected(Product p) async {
    setState(() { _selProduct = p; _selBatch = null; _batches = []; _loading = true; });
    try {
      final list = await widget.controller.loadBatchesForProduct(p.id);
      setState(() {
        _batches = list;
        if (list.isNotEmpty) _selBatch = list.first;
        _loading = false;
      });
    } catch (_) { setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.isIn ? AppTheme.successColor : AppTheme.dangerColor;
    final gradient = widget.isIn ? AppTheme.successGradient : AppTheme.dangerGradient;

    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      padding: EdgeInsets.fromLTRB(24, 20, 24, MediaQuery.of(context).viewInsets.bottom + 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(width: 36, height: 4, decoration: BoxDecoration(
              color: AppTheme.borderColor, borderRadius: BorderRadius.circular(2),
            )),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  widget.isIn ? Icons.south_west_rounded : Icons.north_east_rounded,
                  color: Colors.white, size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Text('Chọn sản phẩm', style: AppTheme.headlineStyle.copyWith(fontSize: 17)),
            ],
          ),
          const SizedBox(height: 20),
          if (_loading)
            const Expanded(child: Center(child: CircularProgressIndicator(color: AppTheme.primaryColor)))
          else
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DropdownButtonFormField<Product>(
                      value: _selProduct,
                      isExpanded: true,
                      dropdownColor: AppTheme.elevatedColor,
                      hint: const Text('Chọn sản phẩm'),
                      decoration: const InputDecoration(
                        labelText: 'Sản phẩm',
                        prefixIcon: Icon(Icons.inventory_2_outlined, size: 18),
                      ),
                      items: _products.map((p) => DropdownMenuItem(
                        value: p,
                        child: Text('${p.name} (Còn: ${p.currentStock})',
                            style: const TextStyle(fontSize: 13, fontFamily: 'Inter', color: Colors.white70)),
                      )).toList(),
                      onChanged: (p) { if (p != null) _onProductSelected(p); },
                    ),
                    if (_selProduct != null) ...[
                      const SizedBox(height: 14),
                      DropdownButtonFormField<Batch>(
                        value: _selBatch,
                        isExpanded: true,
                        dropdownColor: AppTheme.elevatedColor,
                        hint: const Text('Chọn lô'),
                        decoration: const InputDecoration(
                          labelText: 'Lô hàng',
                          prefixIcon: Icon(Icons.archive_outlined, size: 18),
                        ),
                        items: _batches.map((b) => DropdownMenuItem(
                          value: b,
                          child: Text('${b.batchCode} (Còn: ${b.currentQuantity})',
                              style: const TextStyle(fontSize: 13, fontFamily: 'Inter', color: Colors.white70)),
                        )).toList(),
                        onChanged: (b) => setState(() => _selBatch = b),
                      ),
                    ],
                    if (_selBatch != null) ...[
                      const SizedBox(height: 20),
                      Text('Số lượng', style: AppTheme.labelStyle),
                      const SizedBox(height: 10),
                      ZenithCard(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                        child: Row(
                          children: [
                            _QtyBtn(
                              icon: Icons.remove_rounded,
                              color: AppTheme.dangerColor,
                              onTap: () { if (_qty > 1) setState(() { _qty--; _qtyCtrl.text = '$_qty'; }); },
                            ),
                            Expanded(
                              child: TextField(
                                controller: _qtyCtrl,
                                textAlign: TextAlign.center,
                                keyboardType: TextInputType.number,
                                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                style: AppTheme.numberStyle.copyWith(fontSize: 28),
                                decoration: const InputDecoration(border: InputBorder.none, fillColor: Colors.transparent),
                                onChanged: (v) => setState(() => _qty = (int.tryParse(v) ?? 1).clamp(1, 99999)),
                              ),
                            ),
                            _QtyBtn(
                              icon: Icons.add_rounded,
                              color: AppTheme.successColor,
                              onTap: () { setState(() { _qty++; _qtyCtrl.text = '$_qty'; }); },
                            ),
                          ],
                        ),
                      ),
                      if (!widget.isIn && _qty > (_selBatch!.currentQuantity))
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: ZenithBadge(
                            label: '⚠ Vượt tồn kho (${_selBatch!.currentQuantity})',
                            color: AppTheme.warningColor,
                          ),
                        ),
                    ],
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ZenithButton(
            label: 'THÊM VÀO PHIẾU',
            gradient: gradient,
            icon: Icons.add_shopping_cart_rounded,
            onPressed: (_selProduct == null || _selBatch == null) ? null : () {
              widget.controller.addDraftItem(TransactionItemDraft(
                product: _selProduct!,
                batch: _selBatch!,
                quantity: _qty,
              ));
              Get.back();
            },
          ),
        ],
      ),
    );
  }
}
