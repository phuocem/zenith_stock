// ═══════════════════════════════════════════════════════════════════════════
//  profile_view.dart
// ═══════════════════════════════════════════════════════════════════════════
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/profile_controller.dart';
import '../../../core/theme.dart';
import '../../../core/global_styles.dart';

class ProfileView extends GetView<ProfileController> {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context) {
    final nameCtrl = TextEditingController(text: controller.fullName.value);
    final phoneCtrl = TextEditingController(text: controller.phone.value);

    return Scaffold(
      backgroundColor: AppTheme.bgColor,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('HỒ SƠ CÁ NHÂN'),
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: AppTheme.borderColor)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            _ProfileHero(),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _InfoCard(nameCtrl: nameCtrl, phoneCtrl: phoneCtrl),
                  const SizedBox(height: 16),
                  _AccountCard(),
                  const SizedBox(height: 24),
                  _SaveButton(nameCtrl: nameCtrl, phoneCtrl: phoneCtrl),
                  const SizedBox(height: 12),
                  _LogoutButton(),
                  const SizedBox(height: 32),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileHero extends GetView<ProfileController> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final profile = controller.currentProfile;
      final initials = profile?.initials ?? 'U';
      final name = profile?.displayName ?? 'Người dùng';
      final email = profile?.email ?? '';

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(24, 32, 24, 40),
        decoration: BoxDecoration(
          color: AppTheme.cardColor,
          border: const Border(bottom: BorderSide(color: AppTheme.borderColor)),
        ),
        child: Column(
          children: [
            GlowPulse(
              color: AppTheme.primaryColor,
              child: Container(
                width: 88, height: 88,
                decoration: AppTheme.glowDecoration(color: AppTheme.primaryColor, radius: 44),
                child: Center(
                  child: Text(
                    initials,
                    style: AppTheme.headlineStyle.copyWith(
                      color: AppTheme.primaryColor, fontSize: 34, fontFamily: 'Sora',
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(name, style: AppTheme.headlineStyle.copyWith(fontSize: 20)),
            const SizedBox(height: 4),
            Text(email, style: AppTheme.captionStyle),
            const SizedBox(height: 12),
            ZenithBadge(label: 'ĐANG HOẠT ĐỘNG', color: AppTheme.successColor, dot: true),
          ],
        ),
      );
    });
  }
}

class _InfoCard extends GetView<ProfileController> {
  final TextEditingController nameCtrl;
  final TextEditingController phoneCtrl;
  const _InfoCard({required this.nameCtrl, required this.phoneCtrl});

  @override
  Widget build(BuildContext context) {
    return ZenithCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SectionHeader(title: 'Thông tin cá nhân'),
          const SizedBox(height: 20),
          TextField(
            controller: nameCtrl,
            onChanged: (v) => controller.fullName.value = v,
            style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
            decoration: const InputDecoration(
              labelText: 'Họ và tên',
              prefixIcon: Icon(Icons.person_outline, size: 18),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: phoneCtrl,
            onChanged: (v) => controller.phone.value = v,
            keyboardType: TextInputType.phone,
            style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
            decoration: const InputDecoration(
              labelText: 'Số điện thoại',
              prefixIcon: Icon(Icons.phone_outlined, size: 18),
            ),
          ),
        ],
      ),
    );
  }
}

class _AccountCard extends GetView<ProfileController> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final profile = controller.currentProfile;
      if (profile == null) return const SizedBox.shrink();
      return ZenithCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SectionHeader(title: 'Thông tin tài khoản'),
            const SizedBox(height: 16),
            _InfoRow(Icons.email_outlined, 'Email', profile.email ?? '—'),
            const ZenithDivider(),
            _InfoRow(Icons.badge_outlined, 'Vai trò', profile.roleName ?? '—', valueColor: AppTheme.primaryColor),
            const ZenithDivider(),
            _InfoRow(Icons.security_outlined, 'Trạng thái', 'Đang hoạt động', valueColor: AppTheme.successColor),
          ],
        ),
      );
    });
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color? valueColor;
  const _InfoRow(this.icon, this.label, this.value, {this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(icon, size: 16, color: const Color(0xFF546E7A)),
          const SizedBox(width: 12),
          SizedBox(width: 80, child: Text(label, style: AppTheme.captionStyle)),
          Expanded(
            child: Text(
              value,
              style: AppTheme.captionStyle.copyWith(color: valueColor ?? Colors.white70),
            ),
          ),
        ],
      ),
    );
  }
}

class _SaveButton extends GetView<ProfileController> {
  final TextEditingController nameCtrl;
  final TextEditingController phoneCtrl;
  const _SaveButton({required this.nameCtrl, required this.phoneCtrl});

  @override
  Widget build(BuildContext context) {
    return Obx(() => ZenithButton(
      label: 'LƯU THAY ĐỔI',
      icon: Icons.save_outlined,
      isLoading: controller.isSaving.value,
      onPressed: controller.saveProfile,
    ));
  }
}

class _LogoutButton extends GetView<ProfileController> {
  @override
  Widget build(BuildContext context) {
    return ZenithButton(
      label: 'ĐĂNG XUẤT',
      gradient: AppTheme.dangerGradient,
      icon: Icons.logout_rounded,
      onPressed: controller.logout,
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  admin_view.dart
// ═══════════════════════════════════════════════════════════════════════════
import '../controllers/admin_controller.dart';

class AdminView extends GetView<AdminController> {
  const AdminView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgColor,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('QUẢN LÝ NHÂN VIÊN'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.accentColor),
            onPressed: controller.fetchAll,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
            child: FilledButton.icon(
              onPressed: () => _showCreateUserDialog(context, controller),
              icon: const Icon(Icons.person_add_alt_1_rounded, size: 16),
              label: const Text('Tạo', style: TextStyle(fontFamily: 'Sora', fontSize: 12, fontWeight: FontWeight.w700)),
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.primaryColor,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ),
          const SizedBox(width: 4),
        ],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: AppTheme.borderColor)),
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.users.isEmpty) {
          return const Center(child: CircularProgressIndicator(color: AppTheme.primaryColor));
        }
        if (controller.users.isEmpty) {
          return const EmptyState(message: 'Chưa có nhân viên nào', icon: Icons.people_outline);
        }
        return RefreshIndicator(
          color: AppTheme.primaryColor,
          backgroundColor: AppTheme.cardColor,
          onRefresh: controller.fetchAll,
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
            itemCount: controller.users.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) => FadeSlideItem(
              index: i,
              child: _UserCard(user: controller.users[i], ctrl: controller),
            ),
          ),
        );
      }),
    );
  }

  void _showCreateUserDialog(BuildContext context, AdminController controller) {
    final emailCtrl = TextEditingController();
    final passCtrl = TextEditingController();
    final nameCtrl = TextEditingController();
    int? selectedRole;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppTheme.cardColor,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => Padding(
          padding: EdgeInsets.fromLTRB(24, 24, 24, MediaQuery.of(ctx).viewInsets.bottom + 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppTheme.borderColor, borderRadius: BorderRadius.circular(2)))),
              const SizedBox(height: 20),
              Row(
                children: [
                  Container(width: 38, height: 38,
                    decoration: BoxDecoration(color: AppTheme.primaryColor.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                    child: const Icon(Icons.person_add_alt_1_rounded, color: AppTheme.primaryColor, size: 18)),
                  const SizedBox(width: 12),
                  Text('Tạo tài khoản nhân viên', style: AppTheme.headlineStyle.copyWith(fontSize: 17)),
                ],
              ),
              const SizedBox(height: 24),
              TextField(controller: nameCtrl, style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
                decoration: const InputDecoration(labelText: 'Họ và tên *', prefixIcon: Icon(Icons.person_outline, size: 18))),
              const SizedBox(height: 12),
              TextField(controller: emailCtrl, keyboardType: TextInputType.emailAddress,
                style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
                decoration: const InputDecoration(labelText: 'Email *', prefixIcon: Icon(Icons.email_outlined, size: 18))),
              const SizedBox(height: 12),
              TextField(controller: passCtrl, obscureText: true,
                style: const TextStyle(color: Colors.white, fontFamily: 'Inter'),
                decoration: const InputDecoration(labelText: 'Mật khẩu (ít nhất 6 ký tự) *', prefixIcon: Icon(Icons.lock_outline, size: 18))),
              const SizedBox(height: 20),
              Text('Chức vụ *', style: AppTheme.labelStyle.copyWith(color: Colors.white60)),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                children: controller.roles.map((r) {
                  final id = r['id'] as int;
                  final name = r['name'] as String;
                  final sel = selectedRole == id;
                  final roleColor = id == 1 ? AppTheme.dangerColor : id == 2 ? AppTheme.primaryColor : AppTheme.successColor;
                  return GestureDetector(
                    onTap: () => setState(() => selectedRole = sel ? null : id),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: sel ? roleColor.withOpacity(0.15) : AppTheme.elevatedColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: sel ? roleColor : AppTheme.borderColor),
                      ),
                      child: Text(name, style: TextStyle(color: sel ? roleColor : Colors.white54, fontWeight: sel ? FontWeight.w700 : FontWeight.w400, fontFamily: 'Inter', fontSize: 13)),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 28),
              Obx(() => ZenithButton(
                label: 'TẠO TÀI KHOẢN',
                icon: Icons.person_add_alt_1_rounded,
                isLoading: controller.isLoading.value,
                onPressed: () {
                  if (nameCtrl.text.isEmpty || emailCtrl.text.isEmpty || passCtrl.text.isEmpty || selectedRole == null) {
                    Get.snackbar('Lỗi', 'Vui lòng nhập đầy đủ thông tin'); return;
                  }
                  if (passCtrl.text.length < 6) { Get.snackbar('Lỗi', 'Mật khẩu phải từ 6 ký tự'); return; }
                  controller.createUser(email: emailCtrl.text.trim(), password: passCtrl.text, fullName: nameCtrl.text.trim(), roleId: selectedRole!);
                },
              )),
            ],
          ),
        ),
      ),
    );
  }
}

class _UserCard extends StatelessWidget {
  final Map<String, dynamic> user;
  final AdminController ctrl;
  const _UserCard({required this.user, required this.ctrl});

  @override
  Widget build(BuildContext context) {
    final name = user['full_name'] as String? ?? 'Chưa đặt tên';
    final email = user['email'] as String? ?? '';
    final roleId = user['role_id'] as int?;
    final roleName = ctrl.roleName(roleId);
    final whList = ctrl.userWarehouses(user);
    Color roleColor = switch (roleId) {
      1 => AppTheme.dangerColor,
      2 => AppTheme.primaryColor,
      3 => AppTheme.successColor,
      _ => Colors.white38,
    };

    return ZenithCard(
      borderColor: roleColor.withOpacity(0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 46, height: 46,
                decoration: BoxDecoration(
                  color: roleColor.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: roleColor.withOpacity(0.25)),
                ),
                child: Center(
                  child: Text(
                    name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: TextStyle(color: roleColor, fontWeight: FontWeight.w800, fontSize: 18, fontFamily: 'Sora'),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: AppTheme.titleStyle.copyWith(fontSize: 14)),
                    const SizedBox(height: 2),
                    Text(email, style: AppTheme.captionStyle.copyWith(fontSize: 11)),
                  ],
                ),
              ),
              ZenithBadge(label: roleName.toUpperCase(), color: roleColor, dot: true),
            ],
          ),
          if (whList.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 6, runSpacing: 6,
              children: whList.map((uw) {
                final wh = uw['warehouses'] as Map<String, dynamic>?;
                final whName = wh?['name'] as String? ?? '';
                final isPrimary = uw['is_primary'] as bool? ?? false;
                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: isPrimary ? AppTheme.warningColor.withOpacity(0.1) : AppTheme.elevatedColor,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: isPrimary ? AppTheme.warningColor.withOpacity(0.3) : AppTheme.borderColor),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (isPrimary) ...[
                        const Icon(Icons.star_rounded, size: 10, color: AppTheme.warningColor),
                        const SizedBox(width: 4),
                      ],
                      Text(whName, style: TextStyle(fontSize: 10, color: isPrimary ? AppTheme.warningColor : Colors.white54, fontFamily: 'Inter')),
                    ],
                  ),
                );
              }).toList(),
            ),
          ],
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.manage_accounts_outlined, size: 14),
                  label: const Text('Đổi chức vụ', style: TextStyle(fontSize: 11, fontFamily: 'Inter')),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.accentColor,
                    side: const BorderSide(color: AppTheme.accentColor),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => _showRoleDialog(context),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.warehouse_outlined, size: 14),
                  label: const Text('Phân công kho', style: TextStyle(fontSize: 11, fontFamily: 'Inter')),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppTheme.primaryColor,
                    side: const BorderSide(color: AppTheme.primaryColor),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => _showWarehouseDialog(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showRoleDialog(BuildContext context) {
    final userId = user['id'] as String;
    int? selectedRole = user['role_id'] as int?;
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('Đổi chức vụ'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: ctrl.roles.map((r) {
              final id = r['id'] as int;
              return RadioListTile<int>(
                title: Text(r['name'] as String, style: const TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Inter')),
                value: id, groupValue: selectedRole,
                activeColor: AppTheme.primaryColor,
                onChanged: (v) => setState(() => selectedRole = v),
              );
            }).toList(),
          ),
          actions: [
            TextButton(onPressed: Get.back, child: const Text('Huỷ')),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppTheme.primaryColor, foregroundColor: Colors.black),
              onPressed: () { if (selectedRole != null) ctrl.updateRole(userId, selectedRole!); },
              child: const Text('Lưu'),
            ),
          ],
        ),
      ),
    );
  }

  void _showWarehouseDialog(BuildContext context) {
    final userId = user['id'] as String;
    final assigned = ctrl.userWarehouses(user).map((uw) {
      final wh = uw['warehouses'] as Map<String, dynamic>?;
      return wh?['id'] as int?;
    }).whereType<int>().toSet();

    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('Phân công kho'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: ctrl.warehouses.map((wh) {
                final isAssigned = assigned.contains(wh.id);
                return CheckboxListTile(
                  title: Text(wh.name, style: const TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Inter')),
                  subtitle: Text(wh.code, style: const TextStyle(color: Color(0xFF546E7A), fontSize: 11)),
                  value: isAssigned, activeColor: AppTheme.primaryColor,
                  onChanged: (val) {
                    setState(() {
                      if (val == true) {
                        assigned.add(wh.id);
                        ctrl.assignWarehouse(userId, wh.id, isPrimary: assigned.length == 1);
                      } else {
                        assigned.remove(wh.id);
                        ctrl.removeWarehouse(userId, wh.id);
                      }
                    });
                  },
                );
              }).toList(),
            ),
          ),
          actions: [
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AppTheme.primaryColor, foregroundColor: Colors.black),
              onPressed: Get.back, child: const Text('Xong'),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
//  product_detail_view.dart
// ═══════════════════════════════════════════════════════════════════════════
import 'package:intl/intl.dart';
import '../controllers/inventory_controller.dart';
import '../../../data/models/product_model.dart';

class ProductDetailView extends GetView<InventoryController> {
  const ProductDetailView({super.key});

  @override
  Widget build(BuildContext context) {
    final productId = Get.arguments as String;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      controller.fetchProductDetail(productId);
    });

    return Scaffold(
      backgroundColor: AppTheme.bgColor,
      appBar: AppBar(
        backgroundColor: AppTheme.surfaceColor,
        title: const Text('CHI TIẾT SẢN PHẨM'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.accentColor),
            onPressed: () => controller.fetchProductDetail(productId),
          ),
        ],
        bottom: PreferredSize(preferredSize: const Size.fromHeight(1), child: Container(height: 1, color: AppTheme.borderColor)),
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const Center(child: CircularProgressIndicator(color: AppTheme.primaryColor));
        }
        final product = controller.selectedProduct.value;
        if (product == null) {
          return const EmptyState(message: 'Không tìm thấy sản phẩm', icon: Icons.search_off_rounded);
        }
        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _ProductHeader(product: product),
              const SizedBox(height: 16),
              _StockSummary(product: product),
              const SizedBox(height: 24),
              const SectionHeader(title: 'Danh sách lô hàng'),
              const SizedBox(height: 14),
              _BatchList(),
              const SizedBox(height: 24),
              _ArchiveButton(product: product),
              const SizedBox(height: 32),
            ],
          ),
        );
      }),
    );
  }
}

class _ProductHeader extends StatelessWidget {
  final Product product;
  const _ProductHeader({required this.product});

  @override
  Widget build(BuildContext context) {
    final status = product.stockStatus;
    Color statusColor = switch (status) {
      StockStatus.normal => AppTheme.successColor,
      StockStatus.low => AppTheme.warningColor,
      StockStatus.outOfStock => AppTheme.dangerColor,
    };
    String statusLabel = switch (status) {
      StockStatus.normal => 'BÌNH THƯỜNG',
      StockStatus.low => 'SẮP HẾT',
      StockStatus.outOfStock => 'HẾT HÀNG',
    };

    return ZenithCard(
      borderColor: statusColor.withOpacity(0.15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 70, height: 70,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [statusColor.withOpacity(0.12), statusColor.withOpacity(0.06)]),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: statusColor.withOpacity(0.2)),
                ),
                child: Icon(Icons.inventory_2_rounded, color: statusColor, size: 34),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name, style: AppTheme.headlineStyle.copyWith(fontSize: 18)),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8, runSpacing: 6,
                      children: [
                        ZenithBadge(label: 'SKU: ${product.sku}', color: AppTheme.accentColor),
                        ZenithBadge(label: statusLabel, color: statusColor, dot: true),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          const ZenithDivider(margin: EdgeInsets.zero),
          const SizedBox(height: 14),
          if (product.categoryName != null)
            _InfoRow(Icons.category_outlined, 'Danh mục', product.categoryName!),
          if (product.unitName != null) ...[
            const SizedBox(height: 8),
            _InfoRow(Icons.square_foot_outlined, 'Đơn vị tính', product.unitName!),
          ],
          if (product.supplierName != null) ...[
            const SizedBox(height: 8),
            _InfoRow(Icons.business_outlined, 'Nhà cung cấp', product.supplierName!),
          ],
          if (product.description?.isNotEmpty == true) ...[
            const SizedBox(height: 14),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.02),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.borderColor),
              ),
              child: Text(product.description!, style: AppTheme.captionStyle.copyWith(height: 1.6)),
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _InfoRow(this.icon, this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 14, color: const Color(0xFF546E7A)),
        const SizedBox(width: 8),
        Text('$label:', style: AppTheme.captionStyle),
        const SizedBox(width: 8),
        Expanded(child: Text(value, style: AppTheme.captionStyle.copyWith(color: Colors.white70))),
      ],
    );
  }
}

class _StockSummary extends StatelessWidget {
  final Product product;
  const _StockSummary({required this.product});

  @override
  Widget build(BuildContext context) {
    final pct = product.maxStockLevel > 0
        ? (product.currentStock / product.maxStockLevel).clamp(0.0, 1.0)
        : 0.0;

    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _StockTile('TỒN HIỆN TẠI', product.currentStock.toString(), AppTheme.primaryColor)),
            const SizedBox(width: 10),
            Expanded(child: _StockTile('TỒN TỐI THIỂU', product.minStockLevel.toString(), AppTheme.warningColor)),
            const SizedBox(width: 10),
            Expanded(child: _StockTile('TỒN TỐI ĐA', product.maxStockLevel.toString(), AppTheme.accentColor)),
          ],
        ),
        const SizedBox(height: 12),
        ZenithCard(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Mức tồn kho', style: AppTheme.captionStyle),
                  Text('${(pct * 100).toStringAsFixed(0)}%',
                      style: AppTheme.monoStyle.copyWith(color: AppTheme.primaryColor)),
                ],
              ),
              const SizedBox(height: 8),
              ZenithProgressBar(value: pct.toDouble(), color: AppTheme.primaryColor, height: 6),
            ],
          ),
        ),
      ],
    );
  }
}

class _StockTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  const _StockTile(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Text(value, style: AppTheme.numberStyle.copyWith(color: color, fontSize: 22)),
          const SizedBox(height: 6),
          Text(label, style: AppTheme.labelStyle.copyWith(fontSize: 8), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class _BatchList extends GetView<InventoryController> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      final batches = controller.productBatches;
      if (batches.isEmpty) {
        return const EmptyState(message: 'Chưa có lô hàng nào\nHãy nhập hàng để bắt đầu', icon: Icons.archive_outlined);
      }
      return ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: batches.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => FadeSlideItem(index: i, child: _BatchCard(batch: batches[i])),
      );
    });
  }
}

class _BatchCard extends StatelessWidget {
  final Batch batch;
  const _BatchCard({required this.batch});

  @override
  Widget build(BuildContext context) {
    final isEmpty = batch.currentQuantity == 0;
    return ZenithCard(
      borderColor: isEmpty ? AppTheme.borderColor : AppTheme.primaryColor.withOpacity(0.12),
      child: Row(
        children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
              color: isEmpty ? Colors.white.withOpacity(0.03) : AppTheme.primaryColor.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.archive_rounded,
                color: isEmpty ? const Color(0xFF37474F) : AppTheme.primaryColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(batch.batchCode, style: AppTheme.monoStyle.copyWith(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(height: 3),
                Row(
                  children: [
                    Text(batch.warehouseName ?? 'Kho chính', style: AppTheme.captionStyle.copyWith(fontSize: 11)),
                    if (batch.expiryDate != null) ...[
                      const SizedBox(width: 8),
                      const Icon(Icons.event_outlined, size: 11, color: Color(0xFF37474F)),
                      const SizedBox(width: 3),
                      Text(
                        DateFormat('dd/MM/yyyy').format(batch.expiryDate!),
                        style: AppTheme.monoStyle.copyWith(fontSize: 10),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${batch.currentQuantity}',
                style: AppTheme.numberStyle.copyWith(
                  fontSize: 20,
                  color: isEmpty ? const Color(0xFF37474F) : AppTheme.primaryColor,
                ),
              ),
              Text('/ ${batch.initialQuantity}', style: AppTheme.monoStyle.copyWith(fontSize: 11)),
            ],
          ),
        ],
      ),
    );
  }
}

class _ArchiveButton extends GetView<InventoryController> {
  final Product product;
  const _ArchiveButton({required this.product});

  @override
  Widget build(BuildContext context) {
    return Obx(() => ZenithButton(
      label: 'NGỪNG KINH DOANH',
      gradient: AppTheme.dangerGradient,
      icon: Icons.archive_outlined,
      isLoading: controller.isLoading.value,
      onPressed: () async => controller.archiveProduct(product),
    ));
  }
}
